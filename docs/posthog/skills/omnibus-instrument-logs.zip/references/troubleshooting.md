# Logs troubleshooting - Docs

This page covers troubleshooting for Logs. For setup, see the [installation guide](/docs/logs/installation.md).

## Have a question? Ask PostHog AI

Ask PostHog AI

## Authentication errors

**Problem**: Getting 401 Unauthorized errors when sending logs.

**Solutions**:

-   Verify you're using the correct project token from [Project Settings](https://app.posthog.com/settings/project)
-   Check the Authorization header format: `Bearer <ph_project_token>`
-   If using query parameter, verify the format: `?token=<ph_project_token>`
-   Ensure your project token hasn't been rotated or revoked

## Connection issues

**Problem**: Cannot connect to the PostHog logs endpoint.

**Solutions**:

-   Verify the endpoint URL: `https://us.i.posthog.com/i/v1/logs`
-   Check that your application can make outbound HTTPS requests
-   Ensure firewall rules allow outbound connections to PostHog
-   For self-hosted instances, verify the endpoint is correct for your deployment

## Logs not appearing in PostHog

**Problem**: Logs are being sent but don't appear in the PostHog interface.

**Solutions**:

-   Verify your project token is correct and associated with the right project
-   Check that logs are being sent in the correct OTLP format
-   Ensure your project has access to the Logs feature in PostHog
-   Check the network tab in your browser/application to verify requests are succeeding (200 status)

## Performance issues

**Problem**: High memory usage or slow log processing.

**Solutions**:

-   Adjust the batch size in your OpenTelemetry configuration
-   Use BatchLogRecordProcessor instead of SimpleLogRecordProcessor for better performance
-   Consider filtering logs on the client side to reduce volume
-   Check for network latency between your application and PostHog

## Log format problems

**Problem**: Logs are being received but not parsed correctly.

**Solutions**:

-   Ensure you're using the standard [OTLP log format](https://opentelemetry.io/docs/specs/otel/logs/data-model/)
-   Verify log levels are set correctly (INFO, WARN, ERROR, etc.)
-   Check that log attributes are properly structured
-   Use the OpenTelemetry logging APIs instead of raw log libraries

## Project token authentication issues

**Problem**: Confused about which key to use or how to authenticate.

**Solutions**:

-   Use your **project token** (the same one you use for capturing events)
-   Find it in [Project Settings](https://app.posthog.com/settings/project)
-   You can authenticate in two ways:
    -   **Header**: `Authorization: Bearer <ph_project_token>`
    -   **Query param**: `?token=<ph_project_token>`
-   Do not use your personal API key or other authentication methods

## Self-hosted endpoint issues

**Problem**: Logs not working with self-hosted PostHog.

**Solutions**:

-   Use your self-hosted instance URL instead of `https://us.i.posthog.com`
-   Verify the logs endpoint is enabled on your self-hosted instance
-   Check that the endpoint path is correct: `/logs`
-   Ensure your PostHog version supports the logs feature

## Still having issues?

If you're still experiencing problems:

1.  Verify your OpenTelemetry client configuration matches the examples in the [installation guide](/docs/logs/installation.md)
2.  Test with a simple log message first before sending complex logs
3.  Check the network requests to see the actual HTTP status codes and error messages
4.  Contact PostHog support with your specific error messages and configuration details

### Community questions

Ask a question

### Was this page useful?

HelpfulCould be better