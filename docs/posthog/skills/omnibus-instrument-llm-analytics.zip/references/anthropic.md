# Anthropic LLM analytics installation - Docs

1.  1

    ## Install the PostHog SDK

    Required

    Setting up analytics starts with installing the PostHog SDK for your language. LLM analytics works best with our Python and Node SDKs.

    PostHog AI

    ### Python

    ```bash
    pip install posthog
    ```

    ### Node

    ```bash
    npm install @posthog/ai posthog-node
    ```

2.  2

    ## Install the Anthropic SDK

    Required

    Install the Anthropic SDK. The PostHog SDK instruments your LLM calls by wrapping the Anthropic client. The PostHog SDK **does not** proxy your calls.

    PostHog AI

    ### Python

    ```bash
    pip install anthropic
    ```

    ### Node

    ```bash
    npm install @anthropic-ai/sdk
    ```

    **Proxy note**

    These SDKs **do not** proxy your calls. They only fire off an async call to PostHog in the background to send the data. You can also use LLM analytics with other SDKs or our API, but you will need to capture the data in the right format. See the schema in the [manual capture section](/docs/llm-analytics/installation/manual-capture.md) for more details.

3.  3

    ## Initialize PostHog and the Anthropic wrapper

    Required

    Initialize PostHog with your project token and host from [your project settings](https://app.posthog.com/settings/project), then pass it to our Anthropic wrapper.

    PostHog AI

    ### Python

    ```python
    from posthog.ai.anthropic import Anthropic
    from posthog import Posthog
    posthog = Posthog(
        "<ph_project_token>",
        host="https://us.i.posthog.com"
    )
    client = Anthropic(
        api_key="sk-ant-api...", # Replace with your Anthropic API key
        posthog_client=posthog # This is an optional parameter. If it is not provided, a default client will be used.
    )
    ```

    ### Node

    ```typescript
    import { Anthropic } from '@posthog/ai'
    import { PostHog } from 'posthog-node'
    const phClient = new PostHog(
      '<ph_project_token>',
      { host: 'https://us.i.posthog.com' }
    )
    const client = new Anthropic({
      apiKey: 'sk-ant-api...', // Replace with your Anthropic API key
      posthog: phClient
    })
    ```

    > **Note:** This also works with the `AsyncAnthropic` client as well as `AnthropicBedrock`, `AnthropicVertex`, and the async versions of those.

4.  4

    ## Call Anthropic LLMs

    Required

    Now, when you use the Anthropic SDK to call LLMs, PostHog automatically captures an `$ai_generation` event. You can enrich the event with additional data such as the trace ID, distinct ID, custom properties, groups, and privacy mode options.

    PostHog AI

    ### Python

    ```python
    response = client.messages.create(
        model="claude-3-opus-20240229",
        messages=[
            {
                "role": "user",
                "content": "Tell me a fun fact about hedgehogs"
            }
        ],
        posthog_distinct_id="user_123", # optional
        posthog_trace_id="trace_123", # optional
        posthog_properties={"conversation_id": "abc123", "paid": True}, # optional
        posthog_groups={"company": "company_id_in_your_db"},  # optional
        posthog_privacy_mode=False # optional
    )
    print(response.content[0].text)
    ```

    ### Node

    ```typescript
    const response = await client.messages.create({
      model: "claude-3-5-sonnet-latest",
      messages: [
        {
          role: "user",
          content: "Tell me a fun fact about hedgehogs"
        }
      ],
      posthogDistinctId: "user_123", // optional
      posthogTraceId: "trace_123", // optional
      posthogProperties: { conversationId: "abc123", paid: true }, // optional
      posthogGroups: { company: "company_id_in_your_db" }, // optional
      posthogPrivacyMode: false // optional
    })
    console.log(response.content[0].text)
    phClient.shutdown()
    ```

    > **Notes:**
    >
    > -   This also works when message streams are used (e.g. `stream=True` or `client.messages.stream(...)`).
    > -   If you want to capture LLM events anonymously, **don't** pass a distinct ID to the request.
    >
    > See our docs on [anonymous vs identified events](/docs/data/anonymous-vs-identified-events.md) to learn more.

    You can expect captured `$ai_generation` events to have the following properties:

    | Property | Description |
    | --- | --- |
    | $ai_model | The specific model, like gpt-5-mini or claude-4-sonnet |
    | $ai_latency | The latency of the LLM call in seconds |
    | $ai_time_to_first_token | Time to first token in seconds (streaming only) |
    | $ai_tools | Tools and functions available to the LLM |
    | $ai_input | List of messages sent to the LLM |
    | $ai_input_tokens | The number of tokens in the input (often found in response.usage) |
    | $ai_output_choices | List of response choices from the LLM |
    | $ai_output_tokens | The number of tokens in the output (often found in response.usage) |
    | $ai_total_cost_usd | The total cost in USD (input + output) |
    | [[...]](/docs/llm-analytics/generations.md#event-properties) | See [full list](/docs/llm-analytics/generations.md#event-properties) of properties |

5.  ## Verify traces and generations

    Recommended

    *Confirm LLM events are being sent to PostHog*

    Let's make sure LLM events are being captured and sent to PostHog. Under **LLM analytics**, you should see rows of data appear in the **Traces** and **Generations** tabs.

    ![LLM generations in PostHog](https://res.cloudinary.com/dmukukwp6/image/upload/SCR_20250807_syne_ecd0801880.png)![LLM generations in PostHog](https://res.cloudinary.com/dmukukwp6/image/upload/SCR_20250807_syjm_5baab36590.png)

    [Check for LLM events in PostHog](https://app.posthog.com/llm-analytics/generations)

6.  5

    ## Next steps

    Recommended

    Now that you're capturing AI conversations, continue with the resources below to learn what else LLM Analytics enables within the PostHog platform.

    | Resource | Description |
    | --- | --- |
    | [Basics](/docs/llm-analytics/basics.md) | Learn the basics of how LLM calls become events in PostHog. |
    | [Generations](/docs/llm-analytics/generations.md) | Read about the $ai_generation event and its properties. |
    | [Traces](/docs/llm-analytics/traces.md) | Explore the trace hierarchy and how to use it to debug LLM calls. |
    | [Spans](/docs/llm-analytics/spans.md) | Review spans and their role in representing individual operations. |
    | [Anaylze LLM performance](/docs/llm-analytics/dashboard.md) | Learn how to create dashboards to analyze LLM performance. |

### Community questions

Ask a question

### Was this page useful?

HelpfulCould be better