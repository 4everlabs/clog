# Java feature flags installation - Docs

The best way to install the PostHog Java SDK is with a build system like Gradle or Maven. This ensures you can easily upgrade to the latest versions.

Look up the latest version of [`com.posthog.posthog-server`](https://central.sonatype.com/artifact/com.posthog/posthog-server).

#### Gradle

All you need to do is add the `posthog-server` module to your `build.gradle`:

build.gradle

PostHog AI

```kotlin
dependencies {
  implementation 'com.posthog:posthog-server:2.+'
}
```

#### Maven

All you need to do is add the `posthog-server` module to your `pom.xml`:

pom.xml

PostHog AI

```xml
<dependency>
  <groupId>com.posthog</groupId>
  <artifactId>posthog-server</artifactId>
  <version>LATEST</version>
</dependency>
```

#### Other

See [`com.posthog.posthog-server`](https://central.sonatype.com/artifact/com.posthog/posthog-server) in the Maven Central Repository. Clicking on the latest version shows you options for adding dependencies for other build systems.

### Setup

Java

PostHog AI

```java
import com.posthog.server.PostHog;
import com.posthog.server.PostHogConfig;
import com.posthog.server.PostHogInterface;
class Sample {
  private static final String POSTHOG_API_KEY = "<ph_project_token>";
  private static final String POSTHOG_HOST = "https://us.i.posthog.com";
  public static void main(String args[]) {
    PostHogConfig config = PostHogConfig
            .builder(POSTHOG_API_KEY)
            .host(POSTHOG_HOST)
            .build();
    PostHogInterface posthog = PostHog.with(config);
    posthog.flush(); // send any remaining events
    posthog.close(); // shut down the client
  }
}
```

## Integrating with Spring

To see how to integrate the PostHog SDK with Spring, check out this [sample project](https://github.com/PostHog/posthog-android/tree/main/posthog-samples/posthog-spring-sample).

## Debug mode

If you're not seeing the expected events being captured, or the feature flags being evaluated, you can enable debug mode to see what's happening.

To see detailed logging, set the debug configuration option to true.

Java

PostHog AI

```java
PostHogConfig config = PostHogConfig
          .builder(POSTHOG_API_KEY)
          .host(POSTHOG_HOST)
          .debug(true)
          .build();
```

### Community questions

Ask a question

### Was this page useful?

HelpfulCould be better